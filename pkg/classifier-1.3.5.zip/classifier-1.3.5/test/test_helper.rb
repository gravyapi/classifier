$:.unshift(File.dirname(__FILE__) + '/../lib')

require 'test/unit'
require 'classifier'